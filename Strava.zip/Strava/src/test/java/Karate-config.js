function fn() {
	
	var config = {
		
		profile_write_token: "Bearer 9f4d1430a3f9aec6e3ce3f77d1bc16bbc9491af3",
		profile_read_all_token: "Bearer 8bd3ea29be5ec6b045d91f1daedbc429f411b22f",
		activity_read_all_token: "Bearer fcd9f2ba42fb5d2f47576bf24c9b3c24523a2083",
		activity_write_token: "Bearer 1ab5c094418bfcbdf7975f3b87d9038ef2ea8d7b"
	}
	
	return config;
}