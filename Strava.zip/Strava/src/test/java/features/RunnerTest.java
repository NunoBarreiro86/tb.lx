package features;

import com.intuit.karate.junit5.Karate;

class SampleTest {

    
    @Karate.Test
    Karate testTags() {
        return Karate.run("tags").tags("@TC1").relativeTo(getClass());
    }


}